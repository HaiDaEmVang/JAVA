package giuakyLT;

public interface itiendien {
	public double tinhthanhtien();
}
